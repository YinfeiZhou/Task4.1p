let o1 = {a:1,b:2}
let v = "b"
console.log(o1[v])
