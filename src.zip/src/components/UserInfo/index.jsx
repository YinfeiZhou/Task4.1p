import React from 'react';
import styles from "./index.module.less"

function UserInfo(props) {
    return (
        <div className={styles.UserInfo}>
            <section className="person">
                <img
                    id="avatar"
                    src="/images/avatar.png"
                    alt="Victor"
                />
                <p>I am a bachelor of student study IT at Deakin university.</p>
            </section>
            <div className="line">&nbsp;</div>
            <section className="project">
                <h1>Here's what I've done so far</h1>
                <section className="project-item">
                    <img src="/images/project1.jpeg" alt="Project 1"/>
                    <p>Web Develop Study</p>
                </section>
                <section className="project-item">
                    <img src="/images/project2.jpeg" alt="Project 2"/>
                    <p>React Framework Study</p>
                </section>
            </section>
            <div className="line">&nbsp;</div>
            <section className="photos">
                <h1>My photos</h1>
                <section className="list">
                    <img src="/images/photo/photo1.jpeg" alt="1"/>
                    <img src="/images/photo/photo2.jpeg" alt="2"/>
                    <img src="/images/photo/photo3.jpeg" alt="3"/>
                    <img src="/images/photo/photo4.jpeg" alt="4"/>
                </section>
            </section>
        </div>
    );
}

export default UserInfo;