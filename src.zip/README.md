# 安装项目依赖
```
yarn
```

# 启动项目
```
npm start # 启动前端
npm run serve  # 启动后端
```
# 编译项目
```
npm build
```